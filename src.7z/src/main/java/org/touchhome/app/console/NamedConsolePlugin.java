package org.touchhome.app.console;

public interface NamedConsolePlugin {
    String getName();
}
