package org.touchhome.app.camera.openhub.handler;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class IpCameraContext {
    private final String id;

    public String getThingTypeUID() {
        return id; // ??????
    }

    public String getUID() {
        return id; /// >?????
    }
}
