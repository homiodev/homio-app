package org.touchhome.app.camera.openhub;

/**
 * handles the configuration of camera groups.
 */
// TODO: remove this!!!!!!!!!!
public class GroupConfig {
    private int pollTime, serverPort;
    private boolean motionChangesOrder = true;
    private String ipWhitelist = "";
    private String ffmpegLocation = "";
    private String ffmpegOutput = "";
    private String firstCamera = "";
    private String secondCamera = "";
    private String thirdCamera = "";
    private String forthCamera = "";

    public String getFirstCamera() {
        return firstCamera;
    }

    public String getSecondCamera() {
        return secondCamera;
    }

    public String getThirdCamera() {
        return thirdCamera;
    }

    public String getForthCamera() {
        return forthCamera;
    }

    public boolean getMotionChangesOrder() {
        return motionChangesOrder;
    }

    public String getIpWhitelist() {
        return ipWhitelist;
    }

    public String getFfmpegLocation() {
        return ffmpegLocation;
    }

    public String getFfmpegOutput() {
        return ffmpegOutput;
    }

    public int getServerPort() {
        return serverPort;
    }

    public int getPollTime() {
        return pollTime;
    }
}
