package org.touchhome.app.camera.openhub;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.util.ReferenceCountUtil;
import org.touchhome.app.camera.openhub.IpCameraBindingConstants.FFmpegFormat;
import org.touchhome.app.camera.openhub.handler.IpCameraHandler;
import org.touchhome.bundle.api.measure.DecimalType;
import org.touchhome.bundle.api.measure.OnOffType;

import java.util.ArrayList;

import static org.touchhome.app.camera.openhub.IpCameraBindingConstants.CHANNEL_THRESHOLD_AUDIO_ALARM;

/**
 * responsible for handling commands for generic and onvif thing types.
 */
public class HttpOnlyHandler extends ChannelDuplexHandler {

    private IpCameraHandler ipCameraHandler;

    public HttpOnlyHandler(IpCameraHandler handler) {
        ipCameraHandler = handler;
    }

    // This handles the incoming http replies back from the camera.
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        ReferenceCountUtil.release(msg);
    }

    // This handles the commands that come from the Openhab event bus.
    public void handleCommand(ChannelUID channelUID, String command) {
        if (command.equals("RefreshType")) {
            return; // Return as we have handled the refresh command above and don't need to
            // continue further.
        } // end of "REFRESH"
        switch (channelUID.getId()) {
            case CHANNEL_THRESHOLD_AUDIO_ALARM:
                if (OnOffType.ON.equals(command)) {
                    ipCameraHandler.audioAlarmEnabled = true;
                } else if (OnOffType.OFF.equals(command) || DecimalType.ZERO.equals(command)) {
                    ipCameraHandler.audioAlarmEnabled = false;
                } else {
                    ipCameraHandler.audioAlarmEnabled = true;
                    try {
                        ipCameraHandler.audioThreshold = Integer.valueOf(command.toString());
                    } catch (NumberFormatException e) {
                        ipCameraHandler.getLog().warn("Audio Threshold recieved an unexpected command, was it a number?");
                    }
                }
                ipCameraHandler.setupFfmpegFormat(FFmpegFormat.RTSP_ALARMS);
        }
    }

    // If a camera does not need to poll a request as often as snapshots, it can be
    // added here. Binding steps through the list and sends 1 every 8 seconds.
    public ArrayList<String> getLowPriorityRequests() {
        return new ArrayList<>(0);
    }
}
