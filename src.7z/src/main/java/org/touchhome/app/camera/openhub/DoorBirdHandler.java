package org.touchhome.app.camera.openhub;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.util.ReferenceCountUtil;
import org.touchhome.app.camera.openhub.handler.IpCameraHandler;
import org.touchhome.bundle.api.measure.OnOffType;

import java.util.ArrayList;

import static org.touchhome.app.camera.openhub.IpCameraBindingConstants.*;

/**
 * responsible for handling commands, which are sent to one of the channels.
 */
public class DoorBirdHandler extends ChannelDuplexHandler {
    private IpCameraHandler ipCameraHandler;

    public DoorBirdHandler(IpCameraHandler handler) {
        ipCameraHandler = handler;
    }

    // This handles the incoming http replies back from the camera.
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        if (msg == null || ctx == null) {
            return;
        }
        try {
            String content = msg.toString();
            ipCameraHandler.getLog().trace("HTTP Result back from camera is \t:{}:", content);
            if (content.contains("doorbell:H")) {
                ipCameraHandler.setChannelState(CHANNEL_DOORBELL, OnOffType.ON);
            }
            if (content.contains("doorbell:L")) {
                ipCameraHandler.setChannelState(CHANNEL_DOORBELL, OnOffType.OFF);
            }
            if (content.contains("motionsensor:L")) {
                ipCameraHandler.noMotionDetected(CHANNEL_MOTION_ALARM);
            }
            if (content.contains("motionsensor:H")) {
                ipCameraHandler.motionDetected(CHANNEL_MOTION_ALARM);
            }
        } finally {
            ReferenceCountUtil.release(msg);
        }
    }

    // This handles the commands that come from the Openhab event bus.
    public void handleCommand(ChannelUID channelUID, String command) {
        if (command.equals("RefreshType")) {
            return;
        } // end of "REFRESH"
        switch (channelUID.getId()) {
            case CHANNEL_ACTIVATE_ALARM_OUTPUT:
                if (command.equals("ON")) {
                    ipCameraHandler.sendHttpGET("/bha-api/open-door.cgi");
                }
                return;
            case CHANNEL_ACTIVATE_ALARM_OUTPUT2:
                if (command.equals("ON")) {
                    ipCameraHandler.sendHttpGET("/bha-api/open-door.cgi?r=2");
                }
                return;
            case CHANNEL_EXTERNAL_LIGHT:
                if (command.equals("ON")) {
                    ipCameraHandler.sendHttpGET("/bha-api/light-on.cgi");
                }
        }
    }

    // If a camera does not need to poll a request as often as snapshots, it can be
    // added here. Binding steps through the list.
    public ArrayList<String> getLowPriorityRequests() {
        return new ArrayList<>(1);
    }
}
