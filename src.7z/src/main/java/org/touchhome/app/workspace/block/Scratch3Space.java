package org.touchhome.app.workspace.block;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Scratch3Space {
    private int spaceCount;
}
