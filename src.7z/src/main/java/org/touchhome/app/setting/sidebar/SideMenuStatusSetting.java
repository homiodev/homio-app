package org.touchhome.app.setting.sidebar;

import org.touchhome.bundle.api.setting.SettingPluginBoolean;

public class SideMenuStatusSetting implements SettingPluginBoolean {

    @Override
    public int order() {
        return 2;
    }
}
