package org.touchhome.app.model.entity.widget.impl.chart;

public enum LineInterpolation {
    curveBasis,
    curveCardinal,
    curveLinear,
    curveStep
}
