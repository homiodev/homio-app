package org.touchhome.app.model.entity.widget;

public enum VerticalPosition {
    Top, Middle, Bottom
}
