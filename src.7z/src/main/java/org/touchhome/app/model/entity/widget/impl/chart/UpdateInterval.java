package org.touchhome.app.model.entity.widget.impl.chart;

public enum UpdateInterval {
    Never,
    TenSeconds,
    HalfMinute,
    Minute
}
