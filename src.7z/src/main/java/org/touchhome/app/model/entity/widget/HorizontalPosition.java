package org.touchhome.app.model.entity.widget;

public enum HorizontalPosition {
    Left, Center, Right
}
