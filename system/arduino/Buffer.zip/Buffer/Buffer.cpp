#include "Buffer.h"

uint8_t fromIndex = 0;
uint8_t payloadIndex = 0;
uint8_t offsetWriteIndex = 0;

char payload[32];
char floatBuf[8];


/*void printPayload() {
    if (DEBUG_BUFFER) {
        printf("\nGot. [");
        for (uint8_t i = 0; i < 31; i++) {
            printf("%d, ", payload[i]);
        }
        printf("]");
    }
}*/