#include <stdint.h>

//#pragma once
#ifndef UNTITLED_BUFFER2_H
#define UNTITLED_BUFFER2_H
#define DEBUG_BUFFER 1

extern uint8_t fromIndex;
extern uint8_t payloadIndex;
extern uint8_t offsetWriteIndex;

extern char payload[32];
extern char floatBuf[8];

inline char* getPayload() {
    return payload;
}

union intConvertor {
    struct {
        char buff[2];
    } nybble;
    unsigned int whole;
};

union longConvertor {
    struct {
        char buff[8];
    } nybble;
    uint64_t whole;
};

inline void clearPayload() {
    for (int x = 0; x < 32; x++)
        payload[x] = 0;
}

inline void reseIndex() {
    payloadIndex = 0;
}

inline void addToCurrentIndex(uint8_t value) {
	payloadIndex+=value;
}

inline void setIndex(uint8_t value) {
    payloadIndex = value;
}

inline void setFromIndex(uint8_t value) {
    fromIndex = value;
}

inline void setFromAsIndex() {
    fromIndex = payloadIndex;
}

inline void writeByteAt(uint8_t i, uint8_t value) {
    payload[i] = value;
}

inline void writeByte(uint8_t value) {
    payload[fromIndex + payloadIndex++] = value;
}

inline void writeChar(char value) {
    payload[fromIndex + payloadIndex++] = value;
}

inline char copy(char from[], char to[], uint8_t fromIndex, uint8_t toIndex, uint8_t size) {
    for(uint8_t i = 0; i < size; i++) {
        to[toIndex + i] = from[fromIndex + i];
    }
}

inline void setOffsetWrite(uint8_t value) {
    offsetWriteIndex = value;
}

inline void resetAll() {
    payloadIndex = 0;
    fromIndex = 0;
}

inline void beginWrite() {
    payloadIndex = 0;
    fromIndex = offsetWriteIndex;
}

inline uint8_t getCurrentIndex() {
    return payloadIndex;
}

inline void writeUInt(unsigned int value) {
    union intConvertor data{};
    data.whole = value;
    payload[fromIndex + payloadIndex] = data.nybble.buff[0];
    payload[fromIndex + payloadIndex + 1] = data.nybble.buff[1];
    payloadIndex += 2;
}

inline void writeULong(unsigned long value) {
    union longConvertor data{};
    data.whole = value;
    for (uint8_t i = 0; i < 8; i++) {
        payload[payloadIndex + i] = data.nybble.buff[i];
    }
    payloadIndex += 8;
}

inline uint64_t readULong() {
    union longConvertor data{};
    for (uint8_t i = 0; i < 8; i++) {
        data.nybble.buff[7 - i] = payload[i + fromIndex + payloadIndex];
    }
    payloadIndex += 8;
    return data.whole;
}

inline unsigned int readUInt() {
    union intConvertor data{};
    data.nybble.buff[0] = payload[fromIndex + payloadIndex + 1];
    data.nybble.buff[1] = payload[fromIndex + payloadIndex];
    payloadIndex += 2;
    return data.whole;
}

inline uint8_t readByte() {
    return uint8_t(payload[fromIndex + payloadIndex++]);
}

inline char readChar() {
    return payload[fromIndex + payloadIndex++];
}

inline char peekCharAbsolute(uint8_t offset) {
    return payload[offset];
}

inline uint8_t* getUPayload() {
	return reinterpret_cast<uint8_t *>(payload);
}

#endif //UNTITLED_BUFFER2_H