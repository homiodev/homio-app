/*
 * Copyright (c) 2014 Kees Bakker.  All rights reserved.
 * 
 * This file is part of RTCTimer2.
 * 
 * RTCTimer2 is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3 of
 * the License, or(at your option) any later version.
 *
 * RTCTimer2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with RTCTimer2.  If not, see
 * <http://www.gnu.org/licenses/>.
 */

/*
 * The RTCTimer2 can be used to implement a simple scheduler.
 * It was inspired by the Arduino Timer library by Simon Monk.
 */

#include "RTCTimer2.h"
#include <Arduino.h>
//#include "Diag.h"

#if 0
every::RTCEvent()
{
  _eventType = RTCEvent_None;
  _lastEventTime = 0;
  _period = 0;
  _callback = 0;
  pinID = -1;
  param1 = -1;
  param2 = -1;
  param3 = -1;
}

RTCTimer2::RTCTimer2()
{
}
#endif

char RTCTimer2::getActiveTasksCount() {
	char activeCount = 0;
    for (uint8_t i = 0; i < sizeof(_events) / sizeof(_events[0]); ++i) {
        if (_events[i]._eventType != RTCEvent::RTCEvent_None) {
			activeCount++;
        }
    }
	return activeCount;
}

bool RTCTimer2::update(uint32_t now) {
    bool updated = false;
	for (uint8_t i = 0; i < sizeof(_events) / sizeof(_events[0]); ++i) {
        if (_events[i]._eventType != RTCEvent::RTCEvent_None) {
            if (_events[i].update(now)) {
				updated = true;
            }
        }
    }
	return updated;
}

bool RTCEvent::update(uint32_t now) {
    bool doneEvent = false;
    if ((int32_t) (now - (_lastEventTime + _period * 1000)) >= 0) {
        if (_lastEventTime == 0) {
            // In case this wasn't initialized properly
            _lastEventTime = now;
        } else {
            while ((int32_t) (now - (_lastEventTime + _period * 1000)) >= 0) {
                // Skip all the events that are in the past
                _lastEventTime += _period * 1000;
            }
        }
        switch (_eventType) {
            case RTCEvent_Every:
                (*_callback)(now, pinID, param1, param2, param3);
                break;
            case RTCEvent_Once:
                (*_callback)(now, pinID, param1, param2, param3);
                _eventType = RTCEvent::RTCEvent_None;
                break;
            default:
                break;
        }
        doneEvent = true;
    }
    return doneEvent;
}

uint8_t RTCTimer2::everyOnceOne(uint8_t period, void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2,
                                             uint8_t param3), uint8_t pinID,
                            uint8_t param1) {
    everyOnceTwo(period, callback, pinID, param1, -1);
}

uint8_t RTCTimer2::everyOnceTwo(uint8_t period, void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2,
                                             uint8_t param3),
                            uint8_t pinID, uint8_t param1, uint8_t param2) {
    everyOnceThree(period, callback, pinID, param1, param2, -1);
}

uint8_t RTCTimer2::everyOnceThree(uint8_t period, void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2,
                                             uint8_t param3), uint8_t pinID, uint8_t param1, uint8_t param2,
                            uint8_t param3) {
    everyFull(period, RTCEvent::RTCEvent_Once, callback, pinID, param1, param2, param3);
}

uint8_t RTCTimer2::everyFull(uint8_t period, RTCEvent::RTCEventType eventType,
                            void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2,
                                             uint8_t param3), uint8_t pinID, uint8_t param1, uint8_t param2,
                            uint8_t param3) {
    uint8_t i = findFreeEventIndex();
    if (i == -1)
        return -1;

    _events[i]._eventType = eventType;
    _events[i]._period = period;
    _events[i]._callback = callback;
    _events[i]._lastEventTime = millis();
	_events[i].pinID = pinID;
    _events[i].param1 = param1;
    _events[i].param2 = param2;
    _events[i].param3 = param3;

    return i;
}

uint8_t RTCTimer2::everyOne(uint8_t period,
                        void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3),
                        uint8_t pinID,
                        uint8_t param1) {
    everyTwo(period, callback, pinID, param1, -1);
}

uint8_t RTCTimer2::everyTwo(uint8_t period,
                        void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3),
                        uint8_t pinID, uint8_t param1, uint8_t param2) {
    everyThree(period, callback, pinID, param1, param2, -1);
}

uint8_t RTCTimer2::everyThree(uint8_t period,
                        void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3),
                        uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3) {
    everyFull(period, RTCEvent::RTCEvent_Every, callback, pinID, param1, param2, param3);
}

void RTCTimer2::cancelBy1Params(uint8_t pinID, uint8_t param1) {
    cancelBy3Params(pinID, param1, -1, -1);
}

void RTCTimer2::cancelBy2Params(uint8_t pinID, uint8_t param1, uint8_t param2) {
    cancelBy3Params(pinID, param1, param2, -1);
}

void RTCTimer2::cancelBy3Params(uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3) {
    for (uint8_t i = 0; i < sizeof(_events) / sizeof(_events[0]); ++i) {
        if (_events[i]._eventType != RTCEvent::RTCEvent_None) {
			if(_events[i].pinID == pinID) {
				if(_events[i].param1 == param1 && _events[i].param2 == param2 && _events[i].param3 == param3) {
					_events[i]._eventType = RTCEvent::RTCEvent_None;
					return;
				}
			}
        }
    }
}

/*
 * Reset the "last event" time of all events to the new value.
 *
 * This function should be called once (e.g. in setup() after creating
 * all the ...
 */
void RTCTimer2::resetAll(uint32_t now) {
    for (uint8_t i = 0; i < sizeof(_events) / sizeof(_events[0]); ++i) {
        if (_events[i]._eventType != RTCEvent::RTCEvent_None) {
            _events[i]._lastEventTime = now;
        }
    }
}

void RTCTimer2::cancel(uint8_t i) {
    _events[i]._eventType = RTCEvent::RTCEvent_None;
}

bool RTCTimer2::update() {
    return update(millis());
}

uint8_t RTCTimer2::findFreeEventIndex() {
    for (uint8_t i = 0; i < sizeof(_events) / sizeof(_events[0]); ++i) {
        if (_events[i]._eventType == RTCEvent::RTCEvent_None) {
            return i;
        }
    }
    return -1;
}

