/*
 * Copyright (c) 2014 Kees Bakker.  All rights reserved.
 *
 * This file is part of RTCTimer2.
 *
 * RTCTimer2 is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3 of
 * the License, or(at your option) any later version.
 *
 * RTCTimer2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with RTCTimer2.  If not, see
 * <http://www.gnu.org/licenses/>.
 */

#include <stdint.h>

#ifndef RTCTIMER2_H_
#define RTCTIMER2_H_

#define MAX_NUMBER_OF_RTCEVENTS (21)

class RTCTimer2;
class RTCEvent
{
  friend class RTCTimer2;
public:
  enum RTCEventType {
    RTCEvent_None = 0,
    RTCEvent_Every,
    RTCEvent_Once
  };
  //RTCEvent();

  bool update(uint32_t now);

protected:
  enum RTCEventType _eventType;
  uint32_t _lastEventTime;
  uint8_t _period;
  uint8_t pinID;
  uint8_t param1;
  uint8_t param2;
  uint8_t param3;
  void (*_callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3);
};

class RTCTimer2
{
public:
  //RTCTimer2();

  uint8_t everyOnceOne(uint8_t period, void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3), uint8_t pinID, uint8_t param1);
  uint8_t everyOnceTwo(uint8_t period, void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3), uint8_t pinID, uint8_t param1, uint8_t param2);
  uint8_t everyOnceThree(uint8_t period, void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3), uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3);

  uint8_t everyOne(uint8_t period, void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3), uint8_t pinID, uint8_t param1);
  uint8_t everyTwo(uint8_t period, void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3), uint8_t pinID, uint8_t param1, uint8_t param2);
  uint8_t everyThree(uint8_t period, void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3), uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3);

  uint8_t everyFull(uint8_t period, RTCEvent::RTCEventType eventType, void (*callback)(uint32_t now, uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3), uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3);

  void cancel(uint8_t eventHandler);
  void cancelBy1Params(uint8_t pinID, uint8_t param1);
  void cancelBy2Params(uint8_t pinID, uint8_t param1, uint8_t param2);
  void cancelBy3Params(uint8_t pinID, uint8_t param1, uint8_t param2, uint8_t param3);

  char getActiveTasksCount();
  void resetAll(uint32_t now);
  bool update();
  bool update(uint32_t now);

protected:
  uint8_t       findFreeEventIndex();
  RTCEvent      _events[MAX_NUMBER_OF_RTCEVENTS];
};

#endif /* RTCTIMER2_H_ */
